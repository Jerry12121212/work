package com.ly.member.activity.modules.job.dao;

import com.ly.member.activity.modules.job.entity.ChallengeTask;
import com.ly.member.activity.modules.job.entity.ChallengeTaskExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface ChallengeTaskMapper {
    long countByExample(ChallengeTaskExample example);

    int deleteByExample(ChallengeTaskExample example);

    int insert(ChallengeTask record);

    int insertSelective(ChallengeTask record);

    List<ChallengeTask> selectByExample(ChallengeTaskExample example);

    int updateByExampleSelective(@Param("record") ChallengeTask record, @Param("example") ChallengeTaskExample example);

    int updateByExample(@Param("record") ChallengeTask record, @Param("example") ChallengeTaskExample example);
}